"use client"

import { useState, useEffect, useRef } from "react"
import { addDays, format, differenceInDays } from "date-fns"
import { es } from "date-fns/locale"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useMediaQuery } from "@/hooks/use-media-query"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangleIcon } from "lucide-react"

interface Phase {
  id: string
  name: string
  durationWeeks: number
  durationDays: number
  startDay: number
  endDay: number
  startDate: Date
  endDate: Date
  color: string
}

interface GanttChartProps {
  startDate: Date
}

export default function GanttChart({ startDate }: GanttChartProps) {
  const [phases, setPhases] = useState<Phase[]>([])
  const [today] = useState(new Date())
  const isMobile = useMediaQuery("(max-width: 768px)")
  const chartRef = useRef<HTMLDivElement>(null)
  const [projectEndDay, setProjectEndDay] = useState(0)

  useEffect(() => {
    // Define phases with their durations
    const phaseDefinitions = [
      { id: "a1", name: "Adquisición y Pre-procesamiento de Datos", durationWeeks: 5, color: "var(--phase-1)" },
      { id: "a2", name: "Configuración y Entrenamiento del Modelo", durationWeeks: 9, color: "var(--phase-2)" },
      { id: "a3", name: "Operacionalización y Automatización", durationWeeks: 5, color: "var(--phase-3)" },
      { id: "a4", name: "Validación del Piloto y Transferencia", durationWeeks: 5, color: "var(--phase-4)" },
      { id: "a5", name: "Margen de Contingencia", durationWeeks: 2, color: "var(--phase-5)" },
    ]

    // Calculate start and end dates for each phase
    let currentStartDay = 0
    const calculatedPhases = phaseDefinitions.map((phase) => {
      const durationDays = phase.durationWeeks * 7
      const startDay = currentStartDay
      const endDay = startDay + durationDays
      const phaseStartDate = addDays(startDate, startDay)
      const phaseEndDate = addDays(startDate, endDay)

      currentStartDay = endDay

      return {
        ...phase,
        durationDays,
        startDay,
        endDay,
        startDate: phaseStartDate,
        endDate: phaseEndDate,
      }
    })

    setPhases(calculatedPhases)
    setProjectEndDay(calculatedPhases.length > 0 ? calculatedPhases[calculatedPhases.length - 1].endDay : 0)
  }, [startDate])

  // Calculate today's position in the timeline
  const todayPosition = differenceInDays(today, startDate)

  // Generate month labels for the timeline
  const generateMonthLabels = () => {
    if (projectEndDay === 0) return []

    const labels = []
    let currentDate = new Date(startDate)
    const endDate = addDays(startDate, projectEndDay)

    // Set to first day of month
    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)

    while (currentDate <= endDate) {
      const position = differenceInDays(currentDate, startDate)
      const percentage = (position / projectEndDay) * 100

      labels.push({
        date: new Date(currentDate),
        position: percentage,
        label: format(currentDate, "MMM yyyy", { locale: es }),
      })

      // Move to next month
      currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1)
    }

    return labels
  }

  const monthLabels = generateMonthLabels()

  return (
    <Card className="bg-card">
      <CardHeader>
        <CardTitle>Cronograma del Proyecto</CardTitle>
        <CardDescription>Visualización de las fases del proyecto y su duración en el tiempo</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          {/* Custom Gantt Chart */}
          <div className="relative">
            {/* Month labels */}
            <div className="flex border-b mb-2 relative h-8">
              {monthLabels.map((month, index) => (
                <div
                  key={`month-${index}`}
                  className="absolute text-xs font-medium"
                  style={{
                    left: `${month.position}%`,
                    color: "var(--foreground)",
                    textShadow: "0 0 5px var(--background)",
                  }}
                >
                  {month.label}
                </div>
              ))}
            </div>

            {/* Today marker */}
            {todayPosition >= 0 && todayPosition <= projectEndDay && (
              <div
                className="absolute top-8 bottom-0 w-px bg-red-500 z-10"
                style={{ left: `${(todayPosition / projectEndDay) * 100}%` }}
              >
                <div className="bg-red-500 text-white text-xs px-1 py-0.5 rounded absolute -top-6 -translate-x-1/2">
                  Hoy
                </div>
              </div>
            )}

            {/* Gantt bars */}
            <div className="space-y-4">
              {phases.map((phase, index) => (
                <div key={phase.id} className="relative h-12">
                  {/* Phase label */}
                  <div className="absolute left-0 top-0 bottom-0 w-[220px] pr-4 flex items-center">
                    <span className="text-sm font-medium" title={phase.name}>
                      {isMobile ? phase.name.substring(0, 15) + "..." : phase.name}
                    </span>
                  </div>

                  {/* Phase bar */}
                  <div className="ml-[200px] h-full relative">
                    <div
                      className="absolute h-8 top-1/2 -translate-y-1/2 rounded-md"
                      style={{
                        left: `${(phase.startDay / projectEndDay) * 100}%`,
                        width: `${(phase.durationDays / projectEndDay) * 100}%`,
                        backgroundColor: phase.color,
                      }}
                    >
                      <div className="h-full flex items-center justify-center text-sm text-white font-medium px-2 overflow-hidden whitespace-nowrap shadow-sm">
                        {phase.durationWeeks} semanas
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Phase details cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-8">
            {phases.map((phase) => (
              <Card key={phase.id} className="overflow-hidden">
                <div className="h-2" style={{ backgroundColor: phase.color }}></div>
                <CardContent className="pt-4">
                  <h4 className="font-medium text-sm mb-2">{phase.name}</h4>
                  <div className="text-sm space-y-1">
                    <p className="flex justify-between">
                      <span className="text-muted-foreground">Inicio:</span>
                      <span>{format(phase.startDate, "dd/MM/yyyy", { locale: es })}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-muted-foreground">Fin:</span>
                      <span>{format(phase.endDate, "dd/MM/yyyy", { locale: es })}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-muted-foreground">Duración:</span>
                      <Badge variant="outline">{phase.durationWeeks} semanas</Badge>
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Alert variant="warning" className="w-full">
          <AlertTriangleIcon className="h-4 w-4" />
          <AlertDescription>
            Este cronograma no contempla feriados nacionales ni periodos de baja disponibilidad institucional. Se
            ajustará con CEL según disponibilidad.
          </AlertDescription>
        </Alert>
      </CardFooter>
    </Card>
  )
}
