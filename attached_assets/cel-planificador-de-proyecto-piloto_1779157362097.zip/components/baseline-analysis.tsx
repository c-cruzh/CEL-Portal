"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis,
  ReferenceLine,
} from "recharts"

export default function BaselineAnalysis() {
  // Datos para las visualizaciones
  const histogramData = [
    { bin: "-350 a -300", frequency: 5 },
    { bin: "-300 a -250", frequency: 15 },
    { bin: "-250 a -200", frequency: 45 },
    { bin: "-200 a -150", frequency: 120 },
    { bin: "-150 a -100", frequency: 280 },
    { bin: "-100 a -50", frequency: 650 },
    { bin: "-50 a 0", frequency: 2800 },
    { bin: "0 a 50", frequency: 3200 },
    { bin: "50 a 100", frequency: 720 },
    { bin: "100 a 150", frequency: 320 },
    { bin: "150 a 200", frequency: 160 },
    { bin: "200 a 250", frequency: 49 },
  ]

  const qqPlotData = [
    { theoretical: -3, empirical: -5.2 },
    { theoretical: -2.5, empirical: -4.1 },
    { theoretical: -2, empirical: -3.2 },
    { theoretical: -1.5, empirical: -2.1 },
    { theoretical: -1, empirical: -1.3 },
    { theoretical: -0.5, empirical: -0.6 },
    { theoretical: 0, empirical: 0 },
    { theoretical: 0.5, empirical: 0.5 },
    { theoretical: 1, empirical: 1.2 },
    { theoretical: 1.5, empirical: 2.0 },
    { theoretical: 2, empirical: 3.1 },
    { theoretical: 2.5, empirical: 4.0 },
    { theoretical: 3, empirical: 5.3 },
  ]

  const scatterData = []
  for (let i = 0; i < 100; i++) {
    const caudal = Math.random() * 1000
    const error = -0.3 * caudal + Math.random() * 200 - 100
    scatterData.push({ caudal, error })
  }

  const autocorrData = [
    { lag: 0, correlation: 1.0 },
    { lag: 1, correlation: 0.72 },
    { lag: 2, correlation: 0.58 },
    { lag: 3, correlation: 0.45 },
    { lag: 4, correlation: 0.32 },
    { lag: 5, correlation: 0.21 },
    { lag: 6, correlation: 0.15 },
    { lag: 7, correlation: 0.1 },
    { lag: 8, correlation: 0.07 },
    { lag: 9, correlation: 0.05 },
    { lag: 10, correlation: 0.03 },
  ]

  const reservoirData = [
    { embalse: "15se", n: 1941, rmse: 165.0, mae: 63.7, mape: 30.5, error5: 56.1, error10: 46.8 },
    { embalse: "3feb", n: 600, rmse: 46.2, mae: 19.3, mape: 31.4, error5: 70.3, error10: 56.8 },
    { embalse: "5nov", n: 1941, rmse: 40.4, mae: 16.1, mape: 28.6, error5: 64.2, error10: 53.6 },
    { embalse: "cgra", n: 1941, rmse: 124.0, mae: 50.5, mape: 33.1, error5: 58.9, error10: 50.5 },
    { embalse: "guaj", n: 1941, rmse: 34.9, mae: 10.8, mape: 22.8, error5: 58.1, error10: 46.7 },
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle className="text-2xl">
                Informe Diagnóstico de Errores de Pronósticos Manuales de Caudal
              </CardTitle>
              <CardDescription className="mt-2">
                <div className="flex flex-col md:flex-row gap-2 md:gap-6">
                  <span>Conjunto de datos: caudales historico.xlsx – RAW.csv</span>
                  <span>Código de Análisis: Analysis Colab Notebook</span>
                  <span>Fecha: May 9, 2025 3:15 PM EDT</span>
                </div>
              </CardDescription>
            </div>
            <Badge variant="outline" className="px-3 py-1 text-base">
              Línea Base
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="resumen" className="space-y-4">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6">
              <TabsTrigger value="resumen">Resumen</TabsTrigger>
              <TabsTrigger value="metodologia">Metodología</TabsTrigger>
              <TabsTrigger value="precision">Precisión Global</TabsTrigger>
              <TabsTrigger value="embalses">Por Embalse</TabsTrigger>
              <TabsTrigger value="diagnostico">Diagnóstico</TabsTrigger>
              <TabsTrigger value="visualizaciones">Visualizaciones</TabsTrigger>
            </TabsList>

            {/* Resumen Ejecutivo */}
            <TabsContent value="resumen" className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Resumen Ejecutivo</h3>
                <p>
                  Las estimaciones de caudal que actualmente realiza el equipo operativo —basadas en experiencia, reglas
                  empíricas y procesos manuales— presentan desviaciones mayores al ±5% en el 60% de los casos y mayores
                  al ±10% en el 50% de los registros analizados (8.364 observaciones en cinco embalses). Los errores
                  muestran colas pesadas, autocorrelación positiva y heterocedasticidad, lo que confirma la ausencia de
                  un modelo cuantitativo sistemático y la necesidad de integrar los datos.
                </p>
                <p>
                  Este análisis establece el punto de partida sobre el cual se construirá el primer sistema formal de
                  pronósticos.
                </p>
              </div>

              <Card className="bg-muted/50">
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-3">Síntesis</h4>
                  <p className="mb-4">
                    Las mediciones que el personal realiza "a ojo" hoy en día fallan frecuentemente: 6 de cada 10 veces
                    el error supera el 5% y 1 de cada 2 veces supera el 10%. Esto significa que las decisiones sobre
                    apertura de compuertas, generación de energía y seguridad hídrica se basan en cifras que pueden
                    estar considerablemente alejadas de la realidad.
                  </p>
                  <p className="mb-4">
                    Además, los errores no son aleatorios: cuando el caudal es alto, el margen de equivocación crece
                    notablemente y, si un día se subestima o sobrestima el caudal, es muy probable que al día siguiente
                    ocurra lo mismo. Esto revela que el método actual replica sesgos y no incorpora retroalimentación
                    para corregirse.
                  </p>
                  <p>
                    En resumen, este diagnóstico cuantifica el nivel de imprecisión y sus patrones sistemáticos,
                    estableciendo la línea base sobre la cual se deben proponer futuras mejoras basadas en integración
                    de datos y modelos estadísticos.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Datos y Metodología */}
            <TabsContent value="metodologia" className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Datos y Metodología</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li>
                    <strong>Observaciones:</strong> 8.364 registros diarios (ene-2020 – dic-2023).
                  </li>
                  <li>
                    <strong>Variables</strong>
                    <ul className="list-disc pl-6 mt-2">
                      <li>PRONOSTICO: caudal estimado manualmente (m³/s).</li>
                      <li>REAL: caudal observado (m³/s).</li>
                    </ul>
                  </li>
                  <li>
                    <strong>Métricas</strong>
                    <ul className="list-disc pl-6 mt-2">
                      <li>Residual: ε = P−R.</li>
                      <li>Error porcentual absoluto (APE): |ε|/|R|</li>
                    </ul>
                  </li>
                </ul>
                <p className="mt-4">
                  Se calcularon RMSE, MAE, MAPE, Jarque–Bera, Durbin–Watson, Ljung–Box y la correlación ε vs. R.
                </p>
              </div>

              <Card className="bg-muted/50">
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-3">¿Qué significa esto?</h4>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>
                      Las cifras actuales implican que la mitad de las veces el caudal real se desvía más de 10% de la
                      estimación usada para operar.
                    </li>
                    <li>
                      Los patrones de error persistentes y dependientes del caudal revelan que los métodos manuales no
                      capturan la complejidad del río.
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Precisión Global */}
            <TabsContent value="precision" className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Precisión Global de los Pronósticos Manuales</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">RMSE global</h4>
                      <p className="text-3xl font-bold">99.06 m³/s</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">MAE global</h4>
                      <p className="text-3xl font-bold">34.12 m³/s</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">MAPE global</h4>
                      <p className="text-3xl font-bold">28.9%</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Errores {">"}` 5%</h4>
                      <p className="text-3xl font-bold">60.1%</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Errores {">"}` 10%</h4>
                      <p className="text-3xl font-bold">49.9%</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-amber-50">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-amber-800 mb-1">Conclusión clave</h4>
                      <p className="text-lg font-medium text-amber-900">
                        1 de cada 2 pronósticos tiene un error mayor al 10%
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="h-[400px] mt-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { categoria: "Errores < 5%", valor: 39.9 },
                      { categoria: "Errores 5-10%", valor: 10.2 },
                      { categoria: "Errores > 10%", valor: 49.9 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 50 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="categoria"
                      angle={-45}
                      textAnchor="end"
                      height={80}
                      tick={{ fontSize: 12, fontWeight: 500 }}
                      tickMargin={10}
                    />
                    <YAxis
                      label={{
                        value: "Porcentaje de pronósticos (%)",
                        angle: -90,
                        position: "insideLeft",
                        style: { textAnchor: "middle", fontSize: 13, fontWeight: 500 },
                      }}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        padding: "8px 12px",
                        fontSize: "14px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                      }}
                    />
                    <Bar
                      dataKey="valor"
                      fill={(entry) => {
                        if (entry.categoria === "Errores < 5%") return "#22c55e"
                        if (entry.categoria === "Errores 5-10%") return "#f59e0b"
                        return "#ef4444"
                      }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            {/* Desempeño por Embalse */}
            <TabsContent value="embalses" className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Desempeño por Embalse</h3>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Embalse</TableHead>
                    <TableHead className="text-right">N</TableHead>
                    <TableHead className="text-right">RMSE</TableHead>
                    <TableHead className="text-right">MAE</TableHead>
                    <TableHead className="text-right">MAPE %</TableHead>
                    <TableHead className="text-right">% {">"}` 5%</TableHead>
                    <TableHead className="text-right">% {">"}` 10%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reservoirData.map((reservoir) => (
                    <TableRow key={reservoir.embalse}>
                      <TableCell className="font-medium">{reservoir.embalse}</TableCell>
                      <TableCell className="text-right">{reservoir.n.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{reservoir.rmse.toFixed(1)}</TableCell>
                      <TableCell className="text-right">{reservoir.mae.toFixed(1)}</TableCell>
                      <TableCell className="text-right">{reservoir.mape.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{reservoir.error5.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">{reservoir.error10.toFixed(1)}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="h-[400px] mt-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={reservoirData} margin={{ top: 20, right: 30, left: 20, bottom: 50 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="embalse" />
                    <YAxis label={{ value: "Porcentaje (%)", angle: -90, position: "insideLeft" }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        padding: "8px 12px",
                        fontSize: "14px",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                      }}
                    />
                    <Legend />
                    <Bar dataKey="error5" name="Errores {'>'}` 5%" fill="#f59e0b" />
                    <Bar dataKey="error10" name="Errores {'>'}` 10%" fill="#ef4444" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>

            {/* Diagnóstico de Residuales */}
            <TabsContent value="diagnostico" className="space-y-4">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Diagnóstico de Residuales</h3>
                <ol className="list-decimal pl-6 space-y-2">
                  <li>
                    <strong>Distribución:</strong> Los errores no siguen una curva normal y exhiben valores extremos de
                    hasta −338 m³/s y +246 m³/s.
                  </li>
                  <li>
                    <strong>Autocorrelación:</strong> El coeficiente Durbin–Watson = 1.30 indica que los errores de un
                    día tienden a repetirse el siguiente.
                  </li>
                  <li>
                    <strong>Heterocedasticidad:</strong> A mayor caudal, mayor margen de error (correlación 0.82).
                  </li>
                </ol>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Valor mínimo</h4>
                      <p className="text-3xl font-bold text-blue-600">-338 m³/s</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Durbin-Watson</h4>
                      <p className="text-3xl font-bold text-amber-600">1.30</p>
                      <p className="text-xs text-muted-foreground mt-1">(Autocorrelación positiva)</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-sm font-medium text-muted-foreground mb-1">Valor máximo</h4>
                      <p className="text-3xl font-bold text-red-600">+246 m³/s</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Visualizaciones */}
            <TabsContent value="visualizaciones" className="space-y-6">
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-4">Visualizaciones</h3>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Histograma */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Distribución de Errores</CardTitle>
                    <CardDescription>
                      La mayor concentración de errores está cerca de 0 m³/s, pero existen colas pronunciadas hacia
                      ambos extremos.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={histogramData} margin={{ top: 20, right: 30, left: 20, bottom: 50 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="bin"
                            angle={-45}
                            textAnchor="end"
                            height={80}
                            tick={{ fontSize: 12, fontWeight: 500 }}
                            tickMargin={10}
                          />
                          <YAxis
                            label={{
                              value: "Frecuencia",
                              angle: -90,
                              position: "insideLeft",
                              style: { textAnchor: "middle", fontSize: 13, fontWeight: 500 },
                            }}
                            tick={{ fontSize: 12 }}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "white",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                              padding: "8px 12px",
                              fontSize: "14px",
                              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                            }}
                          />
                          <Bar dataKey="frequency" fill="#3b82f6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Las colas indican que, aunque la mayoría de estimaciones están "cerca", existen episodios
                      ocasionales con errores extremadamente altos que pueden comprometer la operación.
                    </p>
                  </CardContent>
                </Card>

                {/* QQ Plot */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">QQ Plot</CardTitle>
                    <CardDescription>
                      Desviaciones sistemáticas respecto a la línea roja de referencia normal: fuertes curvaturas en
                      ambos extremos.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            type="number"
                            dataKey="theoretical"
                            name="Teórico"
                            label={{ value: "Cuantiles teóricos", position: "bottom" }}
                          />
                          <YAxis
                            type="number"
                            dataKey="empirical"
                            name="Empírico"
                            label={{ value: "Cuantiles empíricos", angle: -90, position: "insideLeft" }}
                          />
                          <ZAxis range={[60]} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "white",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                              padding: "8px 12px",
                              fontSize: "14px",
                              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                            }}
                          />
                          <ReferenceLine y={0} stroke="#000" />
                          <ReferenceLine x={0} stroke="#000" />
                          <ReferenceLine
                            stroke="red"
                            strokeWidth={2}
                            segment={[
                              { x: -3, y: -3 },
                              { x: 3, y: 3 },
                            ]}
                          />
                          <Scatter name="QQ Plot" data={qqPlotData} fill="#8884d8" />
                        </ScatterChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Confirma que los errores no siguen una distribución normal; por tanto, supuestos gaussianos para
                      intervalos de confianza son inválidos.
                    </p>
                  </CardContent>
                </Card>

                {/* Scatter Plot */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Error vs. Caudal</CardTitle>
                    <CardDescription>
                      Tendencia descendente: a caudales altos, los errores tienden a ser más negativos y variables.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            type="number"
                            dataKey="caudal"
                            name="Caudal"
                            label={{ value: "Caudal (m³/s)", position: "bottom" }}
                          />
                          <YAxis
                            type="number"
                            dataKey="error"
                            name="Error"
                            label={{ value: "Error (m³/s)", angle: -90, position: "insideLeft" }}
                          />
                          <ZAxis range={[60]} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "white",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                              padding: "8px 12px",
                              fontSize: "14px",
                              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                            }}
                          />
                          <ReferenceLine y={0} stroke="#000" />
                          <Scatter name="Error vs. Caudal" data={scatterData} fill="#82ca9d" />
                        </ScatterChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Evidencia sesgo y heterocedasticidad: el método manual sobre-estima en caudales bajos y sub-estima
                      en caudales altos, además de mostrar mayor varianza cuando el río lleva más agua.
                    </p>
                  </CardContent>
                </Card>

                {/* Autocorrelación */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Autocorrelación</CardTitle>
                    <CardDescription>
                      Correlación muy alta en lag 0 y presencia de correlaciones significativas en los primeros 4 lags.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={autocorrData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="lag" label={{ value: "Lag (días)", position: "bottom" }} />
                          <YAxis label={{ value: "Correlación", angle: -90, position: "insideLeft" }} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "white",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                              padding: "8px 12px",
                              fontSize: "14px",
                              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                            }}
                          />
                          <Bar dataKey="correlation" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">
                      Demuestra que los errores de un día influyen en los de días posteriores: las decisiones manuales
                      propagan sus propios sesgos en el tiempo.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
