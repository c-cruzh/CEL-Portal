import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProjectDescription() {
  return (
    <div className="mb-8">
      <Card className="bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-2xl">Herramienta de Planificación de Proyecto</CardTitle>
          <CardDescription>
            Visualización interactiva del cronograma y presupuesto del Proyecto Piloto CEL
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="about">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="about">Acerca de</TabsTrigger>
              <TabsTrigger value="instructions">Instrucciones</TabsTrigger>
              <TabsTrigger value="features">Características</TabsTrigger>
            </TabsList>
            <TabsContent value="about" className="space-y-4 mt-4">
              <div>
                <h3 className="font-semibold text-lg mb-2">¿Qué es esta herramienta?</h3>
                <p>
                  Esta herramienta de planificación interactiva permite visualizar el cronograma completo del Proyecto
                  Piloto CEL, incluyendo todas las fases, duraciones, costos y recursos asignados. Diseñada
                  específicamente para facilitar la comunicación y seguimiento del proyecto, proporciona una vista clara
                  de la línea de tiempo y el presupuesto.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Beneficios</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Visualización clara de todas las fases del proyecto</li>
                  <li>Cálculo automático de fechas basado en la fecha de inicio seleccionada</li>
                  <li>Resumen detallado del presupuesto y asignación de recursos</li>
                  <li>Interfaz intuitiva y fácil de usar</li>
                  <li>Adaptable a cambios en la planificación</li>
                </ul>
              </div>
            </TabsContent>
            <TabsContent value="instructions" className="space-y-4 mt-4">
              <div>
                <h3 className="font-semibold text-lg mb-2">Cómo usar esta herramienta</h3>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Seleccione una fecha de inicio:</span> Use el selector de fecha para
                    establecer cuándo comenzará el proyecto.
                  </li>
                  <li>
                    <span className="font-medium">Explore el diagrama Gantt:</span> Visualice la línea de tiempo
                    completa del proyecto con todas sus fases.
                  </li>
                  <li>
                    <span className="font-medium">Revise el resumen del proyecto:</span> Consulte los detalles de
                    presupuesto, horas estimadas y costos por fase.
                  </li>
                  <li>
                    <span className="font-medium">Ajuste según sea necesario:</span> Cambie la fecha de inicio para ver
                    cómo afecta al cronograma general.
                  </li>
                </ol>
              </div>
            </TabsContent>
            <TabsContent value="features" className="space-y-4 mt-4">
              <div>
                <h3 className="font-semibold text-lg mb-2">Características principales</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Diagrama de Gantt interactivo con todas las fases del proyecto</li>
                  <li>Cálculo automático de fechas de inicio y fin para cada fase</li>
                  <li>Visualización de la duración en días y semanas</li>
                  <li>Resumen detallado del presupuesto con costos por fase</li>
                  <li>Información sobre horas estimadas y tarifas aplicables</li>
                  <li>Detalles sobre el margen de contingencia</li>
                  <li>Interfaz adaptable a dispositivos móviles y de escritorio</li>
                  <li>Modo claro/oscuro para mayor comodidad visual</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
