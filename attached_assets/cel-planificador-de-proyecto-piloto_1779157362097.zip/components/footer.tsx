export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container mx-auto py-4 px-4 text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} Camila Cruz - Data Strategy & AI Consulting. Todos los derechos reservados.</p>
        <p className="mt-1">Herramienta de planificación para Proyecto Piloto CEL</p>
      </div>
    </footer>
  )
}
