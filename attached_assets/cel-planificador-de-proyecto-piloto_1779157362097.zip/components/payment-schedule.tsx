"use client"

import { useState, useEffect } from "react"
import { addDays, format } from "date-fns"
import { es } from "date-fns/locale"
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts"
import { cn } from "@/lib/utils"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangleIcon } from "lucide-react"

interface Phase {
  id: string
  name: string
  durationDays: number
  hoursPerDay: number
  totalHours: number
  startDay: number
  endDay: number
}

interface PaymentPeriod {
  periodNumber: number
  startDate: Date
  endDate: Date
  hoursWorked: number
  cumulativeHours: number
  amount: number
  cumulativeAmount: number
  isContingency: boolean
}

interface PaymentScheduleProps {
  startDate: Date
}

export default function PaymentSchedule({ startDate }: PaymentScheduleProps) {
  const [paymentPeriods, setPaymentPeriods] = useState<PaymentPeriod[]>([])
  const hourlyRate = 250 // USD per hour
  const regularHours = 700 // Total regular hours before contingency

  useEffect(() => {
    // Define project phases
    const phases: Phase[] = [
      {
        id: "a1",
        name: "Adquisición y Pre-procesamiento de Datos",
        durationDays: 35, // 5 weeks * 7 days
        hoursPerDay: 150 / 35, // 150 hours distributed over 35 days
        totalHours: 150,
        startDay: 0,
        endDay: 35,
      },
      {
        id: "a2",
        name: "Configuración y Entrenamiento del Modelo",
        durationDays: 63, // 9 weeks * 7 days
        hoursPerDay: 250 / 63, // 250 hours distributed over 63 days
        totalHours: 250,
        startDay: 35,
        endDay: 98,
      },
      {
        id: "a3",
        name: "Operacionalización y Automatización",
        durationDays: 35, // 5 weeks * 7 days
        hoursPerDay: 150 / 35, // 150 hours distributed over 35 days
        totalHours: 150,
        startDay: 98,
        endDay: 133,
      },
      {
        id: "a4",
        name: "Validación del Piloto y Transferencia",
        durationDays: 35, // 5 weeks * 7 days
        hoursPerDay: 150 / 35, // 150 hours distributed over 35 days
        totalHours: 150,
        startDay: 133,
        endDay: 168,
      },
      {
        id: "a5",
        name: "Margen de Contingencia",
        durationDays: 14, // 2 weeks * 7 days
        hoursPerDay: 80 / 14, // 80 hours distributed over 14 days
        totalHours: 80,
        startDay: 168,
        endDay: 182,
      },
    ]

    // Calculate payment periods (every 15 days)
    const periods: PaymentPeriod[] = []
    const totalProjectDays = 182 // Including contingency
    const periodCount = Math.ceil(totalProjectDays / 15)

    let cumulativeHours = 0
    let cumulativeAmount = 0

    for (let i = 0; i < periodCount; i++) {
      const periodStartDay = i * 15
      const periodEndDay = Math.min((i + 1) * 15 - 1, totalProjectDays - 1)
      const periodStartDate = addDays(startDate, periodStartDay)
      const periodEndDate = addDays(startDate, periodEndDay)

      // Calculate hours worked in this period
      let hoursWorked = 0

      // For each day in the period, check which phase it belongs to and add the hours
      for (let day = periodStartDay; day <= periodEndDay; day++) {
        const phase = phases.find((p) => day >= p.startDay && day < p.endDay)
        if (phase) {
          hoursWorked += phase.hoursPerDay
        }
      }

      // Round to nearest whole number
      hoursWorked = Math.round(hoursWorked)
      cumulativeHours += hoursWorked

      const amount = hoursWorked * hourlyRate
      cumulativeAmount += amount

      // Determine if this period includes contingency hours
      const isContingency = cumulativeHours > regularHours

      periods.push({
        periodNumber: i + 1,
        startDate: periodStartDate,
        endDate: periodEndDate,
        hoursWorked,
        cumulativeHours,
        amount,
        cumulativeAmount,
        isContingency,
      })
    }

    setPaymentPeriods(periods)
  }, [startDate])

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  // Prepare data for the chart
  const chartData = paymentPeriods.map((period) => ({
    name: `Periodo ${period.periodNumber}`,
    hoursWorked: period.hoursWorked,
    amount: period.amount,
    date: format(period.endDate, "dd/MM/yyyy", { locale: es }),
    isContingency: period.isContingency,
  }))

  // Custom tooltip formatter
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-background border rounded-md shadow-md p-4 text-foreground">
          <p className="font-medium">{label}</p>
          <p className="text-sm text-muted-foreground">Fecha: {data.date}</p>
          <div className="mt-2">
            <p>
              <span className="font-medium">Horas:</span> {payload[0].value} horas
            </p>
            <p>
              <span className="font-medium">Monto:</span> {formatCurrency(payload[1].value)}
            </p>
            {data.isContingency && <p className="text-amber-600 font-medium mt-1">⚠️ Incluye horas de contingencia</p>}
          </div>
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cronograma de Pagos</CardTitle>
          <CardDescription>Estimación de horas trabajadas y montos a facturar cada 15 días</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="h-[450px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 70,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="name"
                    angle={-45}
                    textAnchor="end"
                    height={70}
                    tick={{ fontSize: 13, fontWeight: 500 }}
                    tickMargin={10}
                  />
                  <YAxis
                    yAxisId="left"
                    orientation="left"
                    label={{
                      value: "Horas",
                      angle: -90,
                      position: "insideLeft",
                      style: { textAnchor: "middle", fontSize: 14, fontWeight: 500 },
                    }}
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    label={{
                      value: "USD",
                      angle: 90,
                      position: "insideRight",
                      style: { textAnchor: "middle", fontSize: 14, fontWeight: 500 },
                    }}
                    tickFormatter={(value) => formatCurrency(value)}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar yAxisId="left" dataKey="hoursWorked" name="Horas Trabajadas" fill="var(--phase-1)">
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.isContingency ? "#f59e0b" : "var(--phase-1)"} />
                    ))}
                  </Bar>
                  <Bar yAxisId="right" dataKey="amount" name="Monto a Facturar (USD)" fill="var(--phase-2)">
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.isContingency ? "#ef4444" : "var(--phase-2)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-muted p-4 rounded-md mb-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-[var(--phase-1)]"></div>
                  <span className="text-sm">Horas regulares</span>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <div className="w-4 h-4 rounded-full bg-[#f59e0b]"></div>
                  <span className="text-sm">Horas de contingencia</span>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <div className="w-4 h-4 rounded-full bg-[var(--phase-2)]"></div>
                  <span className="text-sm">Monto regular</span>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <div className="w-4 h-4 rounded-full bg-[#ef4444]"></div>
                  <span className="text-sm">Monto de contingencia</span>
                </div>
              </div>
            </div>

            <Table>
              <TableCaption>
                Cronograma de pagos basado en fecha de inicio: {format(startDate, "PPP", { locale: es })}
              </TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Periodo</TableHead>
                  <TableHead>Fecha Inicio</TableHead>
                  <TableHead>Fecha Fin</TableHead>
                  <TableHead className="text-right">Horas Trabajadas</TableHead>
                  <TableHead className="text-right">Horas Acumuladas</TableHead>
                  <TableHead className="text-right">Monto (USD)</TableHead>
                  <TableHead className="text-right">Monto Acumulado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paymentPeriods.map((period) => (
                  <TableRow key={period.periodNumber} className={cn(period.isContingency && "bg-amber-50")}>
                    <TableCell className="font-medium">
                      Periodo {period.periodNumber}
                      {period.isContingency && <span className="ml-2 text-amber-600 text-xs">⚠️</span>}
                    </TableCell>
                    <TableCell>{format(period.startDate, "dd/MM/yyyy", { locale: es })}</TableCell>
                    <TableCell>{format(period.endDate, "dd/MM/yyyy", { locale: es })}</TableCell>
                    <TableCell className="text-right">{period.hoursWorked}</TableCell>
                    <TableCell className={cn("text-right", period.isContingency && "text-amber-600 font-medium")}>
                      {period.cumulativeHours}
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(period.amount)}</TableCell>
                    <TableCell className={cn("text-right", period.isContingency && "text-amber-600 font-medium")}>
                      {formatCurrency(period.cumulativeAmount)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              <TableFooter>
                <TableRow>
                  <TableCell colSpan={3}>Total</TableCell>
                  <TableCell className="text-right">
                    {paymentPeriods.reduce((sum, period) => sum + period.hoursWorked, 0)}
                  </TableCell>
                  <TableCell className="text-right"></TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(paymentPeriods.reduce((sum, period) => sum + period.amount, 0))}
                  </TableCell>
                  <TableCell className="text-right"></TableCell>
                </TableRow>
              </TableFooter>
            </Table>

            <div className="bg-muted p-4 rounded-md">
              <h3 className="font-medium mb-2">Notas sobre la facturación:</h3>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                <li>Las facturas se emitirán al final de cada periodo de 15 días.</li>
                <li>El monto a facturar se basa en las horas trabajadas durante ese periodo.</li>
                <li>La tarifa aplicada es de {formatCurrency(hourlyRate)} por hora.</li>
                <li>
                  <span className="text-amber-600 font-medium">Los periodos marcados con ⚠️</span> incluyen horas de
                  contingencia que solo se facturarán si son efectivamente utilizadas.
                </li>
                <li>Este cronograma es una estimación y puede ajustarse según el avance real del proyecto.</li>
                <li>
                  <span className="font-medium">
                    Este cronograma no contempla feriados nacionales ni periodos de baja disponibilidad institucional.
                  </span>{" "}
                  Se ajustará con CEL según disponibilidad.
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Alert variant="warning" className="w-full">
            <AlertTriangleIcon className="h-4 w-4" />
            <AlertDescription>
              Este cronograma no contempla feriados nacionales ni periodos de baja disponibilidad institucional. Se
              ajustará con CEL según disponibilidad.
            </AlertDescription>
          </Alert>
        </CardFooter>
      </Card>
    </div>
  )
}
