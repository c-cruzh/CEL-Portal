import Image from "next/image"

export default function Header() {
  return (
    <header className="border-b bg-background">
      <div className="container mx-auto py-4 px-4 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-6 w-full justify-between md:justify-start">
          <div className="flex items-center">
            <Image
              src="/images/cel-logo.png"
              alt="CEL Logo"
              width={150}
              height={50}
              className="h-12 w-auto object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold hidden md:block">Planificador de Proyecto Piloto</h1>
        </div>
        <div className="flex items-center">
          <div className="flex items-center">
            <Image
              src="/images/camila-cruz-logo.png"
              alt="Camila Cruz - Data Strategy & AI Consulting"
              width={200}
              height={50}
              className="h-12 w-auto object-contain"
            />
          </div>
        </div>
      </div>
      <div className="md:hidden container mx-auto pb-4 px-4">
        <h1 className="text-2xl font-bold text-center">Planificador de Proyecto Piloto</h1>
      </div>
    </header>
  )
}
