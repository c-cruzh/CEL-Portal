"use client"

import { useState } from "react"
import { addDays, format } from "date-fns"
import { es } from "date-fns/locale"
import { CalendarIcon, AlertTriangleIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import GanttChart from "./gantt-chart"
import ProjectSummary from "./project-summary"
import PaymentSchedule from "./payment-schedule"
import BaselineAnalysis from "./baseline-analysis"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export default function ProjectTimeline() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  const handleDateSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-card">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
            <div>
              <h2 className="text-lg font-medium mb-3">Fecha de inicio del proyecto</h2>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-[240px] justify-start text-left font-normal",
                      !date && "text-muted-foreground",
                      "border-2 hover:bg-accent",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP", { locale: es }) : "Seleccionar fecha"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={date} onSelect={handleDateSelect} initialFocus locale={es} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex-1 min-w-0">
              {date && (
                <Alert>
                  <InfoIcon className="h-4 w-4" />
                  <AlertTitle>Información del proyecto</AlertTitle>
                  <AlertDescription>
                    <p>
                      El proyecto comenzará el{" "}
                      <span className="font-medium">{format(date, "PPP", { locale: es })}</span> y tendrá una duración
                      estimada de
                      <span className="font-medium"> 23-24 semanas</span>.
                    </p>
                    <p className="mt-1">
                      Con el margen de contingencia, podría extenderse hasta{" "}
                      <span className="font-medium">{format(addDays(date, 182), "PPP", { locale: es })}</span>.
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>

          <Alert variant="warning" className="mt-4">
            <AlertTriangleIcon className="h-4 w-4" />
            <AlertTitle>Nota importante</AlertTitle>
            <AlertDescription>
              Este cronograma no contempla feriados nacionales ni periodos de baja disponibilidad institucional. Se
              ajustará con CEL según disponibilidad.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Tabs defaultValue="gantt" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="gantt">Cronograma Gantt</TabsTrigger>
          <TabsTrigger value="summary">Resumen del Proyecto</TabsTrigger>
          <TabsTrigger value="payments">Cronograma de Pagos</TabsTrigger>
          <TabsTrigger value="baseline">Análisis Diagnóstico</TabsTrigger>
        </TabsList>
        <TabsContent value="gantt" className="space-y-4">
          {date && <GanttChart startDate={date} />}
        </TabsContent>
        <TabsContent value="summary" className="space-y-4">
          <ProjectSummary />
        </TabsContent>
        <TabsContent value="payments" className="space-y-4">
          {date && <PaymentSchedule startDate={date} />}
        </TabsContent>
        <TabsContent value="baseline" className="space-y-4">
          <BaselineAnalysis />
        </TabsContent>
      </Tabs>
    </div>
  )
}
