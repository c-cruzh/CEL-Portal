"use client"

import type React from "react"
import { useState } from "react"

import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"

interface Phase {
  name: string
  hours: number
  rate: number
  cost: number
  color: string
}

export default function ProjectSummary() {
  const phases: Phase[] = [
    {
      name: "Adquisición y Pre-procesamiento de Datos",
      hours: 150,
      rate: 250,
      cost: 37500,
      color: "var(--phase-1)",
    },
    {
      name: "Configuración y Entrenamiento del Modelo",
      hours: 250,
      rate: 250,
      cost: 62500,
      color: "var(--phase-2)",
    },
    {
      name: "Operacionalización y Automatización",
      hours: 150,
      rate: 250,
      cost: 37500,
      color: "var(--phase-3)",
    },
    {
      name: "Validación del Piloto y Transferencia",
      hours: 150,
      rate: 250,
      cost: 37500,
      color: "var(--phase-4)",
    },
  ]

  const contingency = {
    name: "Contingencia (máx.)",
    hours: 80,
    rate: 250,
    cost: 20000,
    color: "var(--phase-5)",
  }

  const [viewMode, setViewMode] = useState<"hours" | "costs">("hours")

  const totalHours = phases.reduce((sum, phase) => sum + phase.hours, 0)
  const totalCost = phases.reduce((sum, phase) => sum + phase.cost, 0)
  const grandTotalHours = totalHours + contingency.hours
  const grandTotalCost = totalCost + contingency.cost

  // Data for pie charts
  const hoursData = [
    ...phases.map((phase) => ({
      name: phase.name,
      value: phase.hours,
      color: phase.color,
    })),
    {
      name: contingency.name,
      value: contingency.hours,
      color: contingency.color,
    },
  ]

  const costData = [
    ...phases.map((phase) => ({
      name: phase.name,
      value: phase.cost,
      color: phase.color,
    })),
    {
      name: contingency.name,
      value: contingency.cost,
      color: contingency.color,
    },
  ]

  return (
    <div
      className="space-y-6"
      style={
        {
          "--phase-1": "hsl(215, 100%, 50%)",
          "--phase-2": "hsl(262, 83%, 58%)",
          "--phase-3": "hsl(142, 76%, 36%)",
          "--phase-4": "hsl(31, 100%, 60%)",
          "--phase-5": "hsl(0, 72%, 51%)",
        } as React.CSSProperties
      }
    >
      <Card className="bg-card">
        <CardHeader>
          <CardTitle>Resumen del Proyecto</CardTitle>
          <CardDescription>Distribución de horas y costos por fase del proyecto</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex justify-center space-x-2 mb-4">
              <div className="inline-flex items-center bg-muted rounded-lg p-1">
                <button
                  onClick={() => setViewMode("hours")}
                  className={`px-4 py-2 text-sm rounded-md transition-colors ${
                    viewMode === "hours"
                      ? "bg-background text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Horas
                </button>
                <button
                  onClick={() => setViewMode("costs")}
                  className={`px-4 py-2 text-sm rounded-md transition-colors ${
                    viewMode === "costs"
                      ? "bg-background text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Costos (USD)
                </button>
              </div>
            </div>

            <div className="h-[450px]">
              <h3 className="text-center font-medium mb-4">
                {viewMode === "hours" ? "Distribución de Horas" : "Distribución de Costos"}
              </h3>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={viewMode === "hours" ? hoursData : costData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => (
                      <text x={0} y={0} textAnchor="middle" fill="#333" style={{ fontSize: "12px", fontWeight: 500 }}>
                        {`${(percent * 100).toFixed(0)}%`}
                      </text>
                    )}
                  >
                    {(viewMode === "hours" ? hoursData : costData).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) =>
                      viewMode === "hours"
                        ? [`${value} horas`, "Horas Estimadas"]
                        : [`$${value.toLocaleString()}`, "Costo Estimado"]
                    }
                    contentStyle={{
                      backgroundColor: "white",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      padding: "8px 12px",
                      fontSize: "14px",
                      boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                    }}
                  />
                  <Legend
                    layout="horizontal"
                    verticalAlign="bottom"
                    align="center"
                    wrapperStyle={{
                      paddingTop: "20px",
                      fontSize: "14px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {phases.map((phase, index) => (
                <div key={phase.name} className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: phase.color }}></div>
                  <div className="text-sm">
                    <span className="font-medium">{phase.name}</span>
                    <span className="text-muted-foreground ml-2">
                      {viewMode === "hours" ? `${phase.hours} horas` : `$${phase.cost.toLocaleString()}`}
                    </span>
                  </div>
                </div>
              ))}
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: contingency.color }}></div>
                <div className="text-sm">
                  <span className="font-medium">{contingency.name}</span>
                  <span className="text-muted-foreground ml-2">
                    {viewMode === "hours" ? `${contingency.hours} horas` : `$${contingency.cost.toLocaleString()}`}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader>
          <CardTitle>Presupuesto del Proyecto</CardTitle>
          <CardDescription>Desglose detallado de horas y costos por fase</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableCaption>Presupuesto total máximo: ${grandTotalCost.toLocaleString()}</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">Fase</TableHead>
                <TableHead className="text-right">Horas Estimadas</TableHead>
                <TableHead className="text-right">Tarifa (USD/h)</TableHead>
                <TableHead className="text-right">Costo (USD)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {phases.map((phase) => (
                <TableRow key={phase.name}>
                  <TableCell className="font-medium">{phase.name}</TableCell>
                  <TableCell className="text-right">{phase.hours}</TableCell>
                  <TableCell className="text-right">${phase.rate}</TableCell>
                  <TableCell className="text-right">${phase.cost.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell>Total</TableCell>
                <TableCell className="text-right">{totalHours}</TableCell>
                <TableCell className="text-right"></TableCell>
                <TableCell className="text-right">${totalCost.toLocaleString()}</TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader>
          <CardTitle>Horas Adicionales / Margen de Contingencia</CardTitle>
          <CardDescription>Presupuesto reservado para ajustes, mejoras o retrasos no previstos</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            En caso de requerirse horas adicionales por ajustes, mejoras o retrasos no previstos, se contempla un margen
            de hasta 80 horas adicionales, facturadas a la misma tarifa, para un presupuesto total máximo de $195,000
            USD.
          </p>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">Concepto</TableHead>
                <TableHead className="text-right">Horas Estimadas</TableHead>
                <TableHead className="text-right">Tarifa (USD/h)</TableHead>
                <TableHead className="text-right">Costo (USD)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">{contingency.name}</TableCell>
                <TableCell className="text-right">{contingency.hours}</TableCell>
                <TableCell className="text-right">${contingency.rate}</TableCell>
                <TableCell className="text-right">${contingency.cost.toLocaleString()}</TableCell>
              </TableRow>
            </TableBody>
            <TableFooter>
              <TableRow>
                <TableCell>Total con Contingencia</TableCell>
                <TableCell className="text-right">{grandTotalHours}</TableCell>
                <TableCell className="text-right"></TableCell>
                <TableCell className="text-right">${grandTotalCost.toLocaleString()}</TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader>
          <CardTitle>Duración del Proyecto</CardTitle>
          <CardDescription>Estimación de tiempo y distribución de la carga de trabajo</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Cronograma General</h3>
            <p>
              La duración estimada del proyecto es de <span className="font-semibold">23 a 24 semanas</span>, con una
              carga aproximada de 30 horas semanales. Este cronograma se deriva directamente de la estimación total de
              700 horas, distribuidas entre las 4 fases del proyecto.
            </p>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-2">Margen de Contingencia</h3>
            <p>
              Adicionalmente, se contempla un margen de contingencia de hasta 80 horas adicionales, lo cual podría
              extender el proyecto en un máximo de <span className="font-semibold">2 a 3 semanas adicionales</span>,
              manteniendo siempre el tope presupuestario de $195,000 USD.
            </p>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-2">Distribución Semanal</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Horas totales del proyecto</p>
                <p className="text-2xl font-bold">{grandTotalHours} horas</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Promedio semanal</p>
                <p className="text-2xl font-bold">~30 horas/semana</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
