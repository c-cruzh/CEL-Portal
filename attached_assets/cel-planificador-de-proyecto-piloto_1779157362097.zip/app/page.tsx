import ProjectTimeline from "@/components/project-timeline"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ProjectDescription from "@/components/project-description"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto py-6 px-4">
        <ProjectDescription />
        <ProjectTimeline />
      </main>
      <Footer />
    </div>
  )
}
